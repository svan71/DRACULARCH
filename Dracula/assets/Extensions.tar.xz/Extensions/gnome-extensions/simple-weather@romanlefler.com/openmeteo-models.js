/*
    Copyright 2026 Roman Lefler

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
export var OmModel;
(function (OmModel) {
    OmModel["AUTO"] = "best_match";
    OmModel["DWD_GERMANY"] = "icon_seamless";
    OmModel["NOAA_US"] = "gfs_seamless";
    OmModel["METEO_FRANCE"] = "meteofrance_seamless";
    OmModel["ECMWF"] = "ecmwf_ifs";
    OmModel["UK_MET_OFFICE"] = "ukmo_seamless";
    OmModel["KMA_KOREA"] = "kma_seamless";
    OmModel["JMA_JAPAN"] = "jma_seamless";
    OmModel["METEO_SWISS"] = "meteoswiss_icon_seamless";
    OmModel["MET_NORWAY"] = "metno_seamless";
    OmModel["GEM_CANADA"] = "gem_seamless";
    OmModel["BOM_AUSTRALIA"] = "bom_access_global";
    OmModel["CMA_CHINA"] = "cma_grapes_global";
    OmModel["KNMI_NETHERLANDS"] = "knmi_seamless";
    OmModel["DMI_DENMARK"] = "dmi_seamless";
    OmModel["ITALIA_METEO"] = "italia_meteo_arpae_icon_2i";
})(OmModel || (OmModel = {}));
export const OmName = {
    "best_match": "Auto",
    "icon_seamless": "DWD Germany",
    "gfs_seamless": "NOAA US",
    "meteofrance_seamless": "M\u00E9t\u00E9o France",
    "ecmwf_ifs": "ECMWF",
    "ukmo_seamless": "UK Met Office",
    "kma_seamless": "KMA Korea",
    "jma_seamless": "JMA Japan",
    "meteoswiss_icon_seamless": "Meteo Swiss",
    "metno_seamless": "Met Norway",
    "gem_seamless": "GEM Canada",
    "bom_access_global": "BOM Australia",
    "cma_grapes_global": "CMA China",
    "knmi_seamless": "KNMI Netherlands",
    "dmi_seamless": "DMI Denmark",
    "italia_meteo_arpae_icon_2i": "Italia Meteo"
};
