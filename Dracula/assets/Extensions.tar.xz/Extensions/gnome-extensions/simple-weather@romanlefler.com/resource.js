/*
    Copyright 2025 Roman Lefler

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
// This file will get appended with variabels in the build step
export function AUTHORS() {
    // @ts-ignore
    return authors;
}
export function GITHASH() {
    // @ts-ignore
    return gitHash;
}

// Inserted

const authors = `
Maintainer/Programmer: Roman Lefler

Contributors: Davide Murtas, miyou379, Grzegorz Szymaszek, Frank Dana

Brazilian Portuguese: Alzemand, André Fernandes
Bulgarian: Lyubomir Vasilev
Chinese: know-nothing-but-123, JiaoxianDu, Davidasx
Czech: lev741
Dutch: hidenosuke, Ontrack16
French: Samuel St. Jean, mdouchin, Neo-29
German: Ahmet Ala
Hungarian: Adamyno, arckster
Indonesian: Fakhrul Rijal
Italian: Davide Murtas
Japanese: hidenosuke
Korean: Jerry Hyun
Polish: Szymon Zielonka
Portugese: André Fernandes
Romanian: ygorigor, Igor Sorocean
Russian: Valetss
Turkish: Ahmet Ala, Samo, berkerozgur`;
const gitHash = `a4326c1`;
