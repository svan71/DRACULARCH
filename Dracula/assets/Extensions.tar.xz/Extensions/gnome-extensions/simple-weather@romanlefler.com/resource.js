/*
    Copyright 2025 Roman Lefler

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
// This file will get appended with variabels in the build step
export function AUTHORS() {
    // @ts-ignore
    return authors;
}
// Inserted

const authors = `
Maintainer/Programmer: Roman Lefler

Contributors: Davide Murtas

Brazilian Portuguese (Português do Brasil): Alzemand, André Fernandes
Bulgarian (български език): Lyubomir Vasilev
Chinese (中文): know-nothing-but-123, JiaoxianDu
Dutch (Nederlands): hidenosuke
French (Français): Samuel St. Jean, mdouchin, & Neo-29
German (Deutsch): Ahmet Ala
Hungarian (magyar nyelv): Adamyno
Indonesian (Bahasa Indonesia): Fakhrul Rijal
Italian (Italiano): Davide Murtas
Japanese (日本語): hidenosuke
Korean (한국어): Jerry Hyun
Portugese (Português): André Fernandes
Romanian (Limba Română): ygorigor
Russian (Русский): Valetss
Turkish (Türkçe): Ahmet Ala, Samo

`;